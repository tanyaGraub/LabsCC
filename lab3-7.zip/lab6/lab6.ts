function sealed(constructor: Function)
{
    Object.seal(constructor);
    Object.seal(constructor.prototype);
}


@sealed
class Car
{
    constructor(public brand: string, public model: string) {}

    @toUpperCase
    getInfo(): string
    {
        return `Марка: ${this.brand}, Модель: ${this.model}`;
    }
}


const car = new Car('Toyota', 'Camry');
car.brand = 'Honda';
car.model = 'Accord';
//Object.defineProperty(Car, 'year', {value: 2078});




/*
function toUpperCase(target: any, propertyKey: string, descriptor: PropertyDescriptor)
{
    const originalMethod = descriptor.value;

    descriptor.value = function(...args: any[]) {
        const result = originalMethod.apply(this, args);
        return result.toUpperCase();
    };
    return descriptor;
}


console.log(car.getInfo());
*/


function toUpperCase(target: any, propertyKey: string, descriptor: PropertyDescriptor)
{
    let originalMethod = descriptor.value;
    descriptor.value = function(...args: String[])
    {
        let result = originalMethod.apply(this, args);
        return result.toUpperCase();
    };
    //return descriptor.value;
}


console.log(car.getInfo());