import { Transport } from "./lab4.ts";

const ownerVehicle = new Transport.OwnerClass(
    "Иванов",
    "Иван",
    "Иванович",
    new Date(1980, 5, 15),
    Transport.TypeDocument.Passport,
    "1234",
    "567890"
);

const vehicle = new Transport.VehicleClass(
    "Toyota",
    "Camry",
    2020,
    "1HGCM82633A123456",
    "A123BC",
    ownerVehicle
);

ownerVehicle.printOwnerInfo();
console.log();
vehicle.printVehicleInfo();
console.log();