"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _____4_ts_1 = require("./\u041B\u0430\u0431\u0430_4.ts");
var ownerVehicle = new _____4_ts_1.Transport.OwnerClass("Иванов", "Иван", "Иванович", new Date(1980, 5, 15), _____4_ts_1.Transport.TypeDocument.Passport, "1234", "567890");
var vehicle = new _____4_ts_1.Transport.VehicleClass("Toyota", "Camry", 2020, "1HGCM82633A123456", "A123BC", ownerVehicle);
ownerVehicle.printOwnerInfo();
console.log();
vehicle.printVehicleInfo();
console.log();
