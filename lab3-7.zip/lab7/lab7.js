var Vehicle = /** @class */ (function () {
    function Vehicle(brand, model, year, color, ownerLastName, vinNumber, ownerFullName, registrationNumber) {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.color = color;
        this.ownerLastName = ownerLastName;
        this.vinNumber = vinNumber;
        this.ownerFullName = ownerFullName;
        this.registrationNumber = registrationNumber;
    }
    Vehicle.prototype.getVehicleInfo = function () {
        return "VIN-\u043D\u043E\u043C\u0435\u0440: ".concat(this.vinNumber, ", \u0412\u043B\u0430\u0434\u0435\u043B\u0435\u0446: ").concat(this.ownerFullName, ", \u0420\u0435\u0433\u0438\u0441\u0442\u0440\u0430\u0446\u0438\u043E\u043D\u043D\u044B\u0439 \u043D\u043E\u043C\u0435\u0440: ").concat(this.registrationNumber);
    };
    return Vehicle;
}());
var VehicleStorageImpl = /** @class */ (function () {
    function VehicleStorageImpl(creationDate, vehicles) {
        this._creationDate = creationDate;
        this._vehicles = vehicles;
    }
    Object.defineProperty(VehicleStorageImpl.prototype, "creationDate", {
        get: function () { return this._creationDate; },
        set: function (value) { this._creationDate = value; },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(VehicleStorageImpl.prototype, "vehicles", {
        get: function () { return this._vehicles; },
        set: function (value) { this._vehicles = value; },
        enumerable: false,
        configurable: true
    });
    VehicleStorageImpl.prototype.getAllVehicles = function () {
        return this._vehicles;
    };
    VehicleStorageImpl.prototype.sortVehiclesByBrand = function () {
        return this._vehicles.sort(function (a, b) { return a.brand.localeCompare(b.brand); });
    };
    VehicleStorageImpl.prototype.getVehiclesByOwnerLastName = function (ownerLastName) {
        return this._vehicles.filter(function (vehicle) { return vehicle.ownerLastName.toLowerCase() === ownerLastName.toLowerCase(); });
    };
    return VehicleStorageImpl;
}());
