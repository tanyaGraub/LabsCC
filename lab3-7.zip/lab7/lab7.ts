class Vehicle
{
    brand: string;
    model: string;
    year: number;
    color: string;
    ownerLastName: string;
    vinNumber: string;
    ownerFullName: string;
    registrationNumber: string;

    constructor(brand: string, model: string, year: number, color: string, ownerLastName: string, vinNumber: string, ownerFullName: string, registrationNumber: string)
    {
        this.brand = brand;
        this.model = model;
        this.year = year;
        this.color = color;
        this.ownerLastName = ownerLastName;
        this.vinNumber = vinNumber;
        this.ownerFullName = ownerFullName;
        this.registrationNumber = registrationNumber;
    }

    getVehicleInfo(): string
    {
        return `VIN-номер: ${this.vinNumber}, Владелец: ${this.ownerFullName}, Регистрационный номер: ${this.registrationNumber}`;
    }
}


interface VehicleStorage<T extends Vehicle>
{
    creationDate: Date;
    vehicles: T[];

    getAllVehicles(): T[];
    sortVehiclesByBrand(): T[];
    getVehiclesByOwnerLastName(ownerLastName: string): T[];
}


class VehicleStorageImpl<T extends Vehicle> implements VehicleStorage<T>
{
    private _creationDate: Date;
    private _vehicles: T[];

    constructor(creationDate: Date, vehicles: T[])
    {
        this._creationDate = creationDate;
        this._vehicles = vehicles;
    }

    get creationDate(): Date {return this._creationDate;}
    set creationDate(value: Date) {this._creationDate = value;}

    get vehicles(): T[] {return this._vehicles;}
    set vehicles(value: T[]) {this._vehicles = value;}

    getAllVehicles(): T[]
    {
        return this._vehicles;
    }

    sortVehiclesByBrand(): T[]
    {
        return this._vehicles.sort((a, b) => a.brand.localeCompare(b.brand));
    }

    getVehiclesByOwnerLastName(ownerLastName: string): T[]
    {
        return this._vehicles.filter(vehicle => vehicle.ownerLastName.toLowerCase() === ownerLastName.toLowerCase());
    }
}

console.log(typeof(10));