//Вариант 1
// Задание 1
function findMax(arr: number[]): number {
    if (arr.length === 0) throw new Error("Массив пуст");
    return Math.max(...arr);
}

function hasNegativeNumber(matrix: number[][]): boolean {
    for (let i = 0; i < matrix.length; i++) {
        for (let j = 0; j < matrix[i].length; j++) {
            if (matrix[i][j] < 0) {
                return true;
            }
        }
    }
    return false;
}
console.log("=== Задание 1 ===");
const numbers = [3.14, 2.71, 1.41, 1.73, 2.23];
console.log("Максимальное число:", findMax(numbers));

const matrix = [
    [1, 0, -3],
    [0, 5, 0],
    [7, 0, 9]
];
console.log("Наличие отрицательных чисел в матрице:", hasNegativeNumber(matrix));

//Задание 2
type NumericTuple = [number, number, number];

function sumOfTuple(tuple: NumericTuple): number {
    return tuple[0] + tuple[1] + tuple[2];
}
console.log("\n=== Задание 2 ===");
const myTuple: NumericTuple = [5, 10, 15];
console.log("Сумма значений кортежа:",sumOfTuple(myTuple));

//Задание 3
enum BallType {
    Football = "Футбольный мяч",
    Basketball = "Баскетбольный мяч",
    Tennis = "Теннисный мяч",
    Volleyball = "Волейбольный мяч",
    Baseball = "Бейсбольный мяч"
}

console.log("\n=== Задание 3 ===");
console.log("Тип принтера:", BallType.Football);

//Задание 4
class Pet {
    name: string = 'Some pet';
    age: number = -1;
    speak() {
        return "No speak. I am fish!";
    }
}

class Dog extends Pet {
    label = "AngryHunter";
    age = 8;
    speak() {
        return "Yaw-Gaw!";
    }
}

class Cat extends Pet {
    name = 'Barsik';
    age = 2;
    speak() {
        return "Miyau!";
    }
}

function displayPetInfo<T extends Pet>(pet: T): void {
    const petInfo: any = {
        type: pet instanceof Dog ? 'Dog' : 
              pet instanceof Cat ? 'Cat' : 'Pet',
        name: pet.name,
        age: pet.age,
        voice: pet.speak()
    };
    
    if (pet instanceof Dog) {
        petInfo.label = pet.label;
    }
    
    console.log(petInfo);
}

console.log("\n=== Задание 4 ===");
const dog = new Dog();
const cat = new Cat();
displayPetInfo(dog);
displayPetInfo(cat);

//Задание 5
interface Ball {
    type: BallType;
    size: number;
    weight: number;
    material: string;
}

const football: Ball = {
    type: BallType.Football,
    size: 68,
    weight: 410,
    material: "Кожаный"
};
console.log("\n=== Задание 5 ===");
console.log("Информация о мяче:");
console.log(JSON.stringify(football, null, 2));