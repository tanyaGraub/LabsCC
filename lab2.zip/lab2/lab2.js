var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
//Вариант 1
// Задание 1
function findMax(arr) {
    if (arr.length === 0)
        throw new Error("Массив пуст");
    return Math.max.apply(Math, arr);
}
function hasNegativeNumber(matrix) {
    for (var i = 0; i < matrix.length; i++) {
        for (var j = 0; j < matrix[i].length; j++) {
            if (matrix[i][j] < 0) {
                return true;
            }
        }
    }
    return false;
}
console.log("=== Задание 1 ===");
var numbers = [3.14, 2.71, 1.41, 1.73, 2.23];
console.log("Максимальное число:", findMax(numbers));
var matrix = [
    [1, 0, -3],
    [0, 5, 0],
    [7, 0, 9]
];
console.log("Наличие отрицательных чисел в матрице:", hasNegativeNumber(matrix));
function sumOfTuple(tuple) {
    return tuple[0] + tuple[1] + tuple[2];
}
console.log("\n=== Задание 2 ===");
var myTuple = [5, 10, 15];
console.log("Сумма значений кортежа:", sumOfTuple(myTuple));
//Задание 3
var BallType;
(function (BallType) {
    BallType["Football"] = "\u0424\u0443\u0442\u0431\u043E\u043B\u044C\u043D\u044B\u0439 \u043C\u044F\u0447";
    BallType["Basketball"] = "\u0411\u0430\u0441\u043A\u0435\u0442\u0431\u043E\u043B\u044C\u043D\u044B\u0439 \u043C\u044F\u0447";
    BallType["Tennis"] = "\u0422\u0435\u043D\u043D\u0438\u0441\u043D\u044B\u0439 \u043C\u044F\u0447";
    BallType["Volleyball"] = "\u0412\u043E\u043B\u0435\u0439\u0431\u043E\u043B\u044C\u043D\u044B\u0439 \u043C\u044F\u0447";
    BallType["Baseball"] = "\u0411\u0435\u0439\u0441\u0431\u043E\u043B\u044C\u043D\u044B\u0439 \u043C\u044F\u0447";
})(BallType || (BallType = {}));
console.log("\n=== Задание 3 ===");
console.log("Тип принтера:", BallType.Football);
//Задание 4
var Pet = /** @class */ (function () {
    function Pet() {
        this.name = 'Some pet';
        this.age = -1;
    }
    Pet.prototype.speak = function () {
        return "No speak. I am fish!";
    };
    return Pet;
}());
var Dog = /** @class */ (function (_super) {
    __extends(Dog, _super);
    function Dog() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.label = "AngryHunter";
        _this.age = 8;
        return _this;
    }
    Dog.prototype.speak = function () {
        return "Yaw-Gaw!";
    };
    return Dog;
}(Pet));
var Cat = /** @class */ (function (_super) {
    __extends(Cat, _super);
    function Cat() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this.name = 'Barsik';
        _this.age = 2;
        return _this;
    }
    Cat.prototype.speak = function () {
        return "Miyau!";
    };
    return Cat;
}(Pet));
function displayPetInfo(pet) {
    var petInfo = {
        type: pet instanceof Dog ? 'Dog' :
            pet instanceof Cat ? 'Cat' : 'Pet',
        name: pet.name,
        age: pet.age,
        voice: pet.speak()
    };
    if (pet instanceof Dog) {
        petInfo.label = pet.label;
    }
    console.log(petInfo);
}
console.log("\n=== Задание 4 ===");
var dog = new Dog();
var cat = new Cat();
displayPetInfo(dog);
displayPetInfo(cat);
var football = {
    type: BallType.Football,
    size: 68,
    weight: 410,
    material: "Кожаный"
};
console.log("\n=== Задание 5 ===");
console.log("Информация о мяче:");
console.log(JSON.stringify(football, null, 2));
