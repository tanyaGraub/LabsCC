//Задание 1
const concatenateNumbers = (num1: number, num2: number): string => {
    return num1.toString() + num2.toString();
};

console.log(concatenateNumbers(5, 10)); 

//Задание 2
const age: number = 21;
let userName: string = "tanuta";
const isStudent: boolean = true;
const hobbies: [string, string, string] = ["писать", "спать", "смотреть мультики"];
let user: { id: number; username: string } = { id: 1, username: "tanuta" };
const address: null = null;
let anything: any = "Праздник к нам приходит";
let unknownType: unknown = 211;

console.log(age, userName, isStudent, hobbies, user, address, anything, unknownType);

//Задание 3
interface Entity { 
    id: number; 
 } 
  
 interface ToJsonStringify extends 
 Entity { 
    name: string; 
    surname?: string; 
 } 
  
 const data: ToJsonStringify = { 
    id: 1, 
    name: "Василий", 
 }

 const jsonString: string = JSON.stringify(data);
 console.log(jsonString);