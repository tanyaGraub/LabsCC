//Задание 1
var concatenateNumbers = function (num1, num2) {
    return num1.toString() + num2.toString();
};
console.log(concatenateNumbers(5, 10));
//Задание 2
var age = 21;
var userName = "tanuta";
var isStudent = true;
var hobbies = ["писать", "спать", "смотреть мультики"];
var user = { id: 1, username: "tanuta" };
var address = null;
var anything = "Праздник к нам приходит";
var unknownType = 211;
console.log(age, userName, isStudent, hobbies, user, address, anything, unknownType);
var data = {
    id: 1,
    name: "Василий",
};
var jsonString = JSON.stringify(data);
console.log(jsonString);
